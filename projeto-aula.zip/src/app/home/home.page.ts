import { Component, inject, OnInit } from '@angular/core';
import { IonToggle, IonCard, IonCardContent, IonCardHeader, IonCardTitle, 
  IonHeader, IonToolbar, IonTitle, IonContent } from '@ionic/angular/standalone';
import { ToggleCustomEvent } from '@ionic/core';
import { PreferenciasService } from '../services/preferencias.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [IonHeader, IonToolbar, IonTitle, IonContent,
            IonCard, IonCardHeader, IonCardTitle, IonCardContent,
            IonToggle],
})
export class HomePage implements OnInit {
  
  private servico = inject(PreferenciasService);

  public modoNoturno: boolean = false;

  ngOnInit() {
    this.definirTema();
  }

  public mudarTema(e: ToggleCustomEvent) {
      const valorAtualizado = e.target.checked;
      this.servico.definirTema(valorAtualizado);
      document.documentElement
        .classList.toggle('ion-palette-dark', valorAtualizado);      
  }

  private async definirTema() {
    const temaNoturnoAtivo = await this.servico.isModoNoturnoAtivado();
    this.modoNoturno = temaNoturnoAtivo;
    document.documentElement
      .classList.toggle('ion-palette-dark', temaNoturnoAtivo);
  }

}
