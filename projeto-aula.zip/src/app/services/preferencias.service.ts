import { inject, Injectable } from '@angular/core';
import { Preferences } from '@capacitor/preferences';

@Injectable({
  providedIn: 'root'
})
export class PreferenciasService {

  public definirTema(modoNoturno: boolean) {
    Preferences.set({
      key: 'modoNoturno',
      value: `${modoNoturno}`
    })
  }

  public async isModoNoturnoAtivado() {
    const modoNoturno = await Preferences.get({
      key: 'modoNoturno'
    })
    
    return modoNoturno.value === 'true'
  }

}
