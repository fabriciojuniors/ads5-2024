import { Component, inject } from '@angular/core';
import {ToastController, ModalController} from '@ionic/angular/standalone';
import { IonToast, IonModal, IonButton, IonHeader, IonToolbar, IonTitle, IonContent } from '@ionic/angular/standalone';
import { MeuModalPage } from '../pages/meu-modal/meu-modal.page';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [IonToast, MeuModalPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButton, IonModal],
})
export class HomePage {
  
  private modalController: ModalController = inject(ModalController);
  private toastController: ToastController = inject(ToastController);

  public mensagem: string = 'conteudo do modal';

  // constructor(private modalController: ModalController) {}

  public fecharModal() {
    this.modalController.dismiss();
  }

  public async abrirModal() {
    const modal = await this.modalController.create({
      component: MeuModalPage, 
    });
    modal.present();
  }

  public async abrirToast() {
    const toast = await this.toastController.create({
        message: 'Meu toast via código',
        duration: 5000,
        color: 'warning'
    });
    toast.present();
  }
}
