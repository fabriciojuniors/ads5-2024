import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ModalController, IonButtons,IonButton, IonContent, IonHeader, IonTitle, IonToolbar } from '@ionic/angular/standalone';

@Component({
  selector: 'app-meu-modal',
  templateUrl: './meu-modal.page.html',
  styleUrls: ['./meu-modal.page.scss'],
  standalone: true,
  imports: [IonButtons, IonButton,IonContent, IonHeader, IonTitle, IonToolbar, CommonModule, FormsModule]
})
export class MeuModalPage implements OnInit {

  private modalController: ModalController = inject(ModalController);

  // constructor(private modalController: ModalController) {}

  public fecharModal() {
    this.modalController.dismiss();
  }

  ngOnInit() {
  }

}
