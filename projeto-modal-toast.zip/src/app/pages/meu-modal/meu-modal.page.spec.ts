import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MeuModalPage } from './meu-modal.page';

describe('MeuModalPage', () => {
  let component: MeuModalPage;
  let fixture: ComponentFixture<MeuModalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(MeuModalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
